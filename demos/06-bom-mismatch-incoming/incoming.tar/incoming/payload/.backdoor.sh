#!/bin/sh
# UNDECLARED file injected during transit
