rollout notes
